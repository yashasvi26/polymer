import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smartphone',
  templateUrl: './smartphone.component.html',
  styleUrls: ['./smartphone.component.css']
})
export class SmartphoneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  mobileType:string="Smartphone"

}
