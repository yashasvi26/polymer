import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basicphone',
  templateUrl: './basicphone.component.html',
  styleUrls: ['./basicphone.component.css']
})
export class BasicphoneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  mobileType:string = "Basic phone"

}
